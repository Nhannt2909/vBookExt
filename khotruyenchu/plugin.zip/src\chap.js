load('config.js');

function execute(url) {
    let response = fetch(url, {
        headers: {
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
    });
    if (response.ok) {
        let doc = response.html();
        Console.log("Doc title: " + doc.select("title").text());
        
        let contentEl = doc.select("div.entry-content").first();
        if (!contentEl) {
            Console.log("Fallback 1: .story-detail-content");
            contentEl = doc.select(".story-detail-content").first();
        }
        if (!contentEl) {
            Console.log("Fallback 2: article");
            contentEl = doc.select("article").first();
        }
        if (!contentEl) {
            Console.log("Fallback 3: .markdown-main-panel");
            contentEl = doc.select(".markdown-main-panel").first();
        }
        if (!contentEl) {
            Console.log("Fallback 4: model-response");
            contentEl = doc.select("[id^=model-response-message-content]").first();
        }

        if (contentEl) {
            Console.log("Content found!");
            // Remove common junk blocks
            contentEl.select(".story-navigation, .reading-tools-bar, .social-share, .baoloi, .entry-meta, script, style, ins,em, .ads-responsive").remove();
            
            // Selective removal of watermarks/ads (even nested ones)
            let elements = contentEl.select("div, span, i, p, a");
            for (let i = 0; i < elements.size(); i++) {
                let el = elements.get(i);
                let text = el.text().toLowerCase();
                let style = String(el.attr("style") || "").toLowerCase();
                
                // Remove hidden elements (Site often uses position:absolute left:-9999px or display:none)
                if (style.indexOf("display:none") >= 0 || style.indexOf("opacity:0") >= 0 || style.indexOf("absolute") >= 0) {
                    el.remove();
                    continue;
                }

                // Remove small elements containing site name
                if (el.tagName() !== 'p' && (text.indexOf("khotruyenchu") >= 0 || text.indexOf("sbs") >= 0) && text.length < 200) {
                    el.remove();
                }
            }

            let html = contentEl.html();
            return Response.success(cleanContent(html));
        } else {
            return Response.error("Không tìm thấy div truyện. Tiêu đề trang: " + doc.select("title").text());
        }
    }
    return Response.error("Lỗi HTTP: " + response.status);
}

function cleanContent(html) {
    if (!html) return "";
    
    let res = html
        .replace(/<script[\s\S]*?<\/script>/gi, "")
        .replace(/<style[\s\S]*?<\/style>/gi, "")
        .replace(/<iframe[\s\S]*?<\/iframe>/gi, "")
        .replace(/<div[^>]*>/gi, "")
        .replace(/<\/div>/gi, "<br>")
        .replace(/<p[^>]*>/gi, "")
        .replace(/<\/p>/gi, "<br><br>")
        .replace(/\[\s*Nội\s*Dung\s*\]/gi, "")
        .replace(/&nbsp;/g, " ")
        .replace(/\<\!\-\-.*\-\>/g, " ")
        .replace(/<br\s*\/?>\s*<br\s*\/?>/gi, "<br><br>")
        .trim();
    
    // Final text-based cleanup
    res = res.replace(/Bạn đang đọc truyện tại khotruyenchu\.obs/gi, "");
    res = res.replace(/Truy cập khotruyenchu\.*? để đọc truyện không quảng cáo rác/gi, "");
    
    return res;
}
